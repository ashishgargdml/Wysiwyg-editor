const Welcome = () => {
  return (
    <>
      <h2>Welcome Page</h2>
    </>
  );
};

export default Welcome;
